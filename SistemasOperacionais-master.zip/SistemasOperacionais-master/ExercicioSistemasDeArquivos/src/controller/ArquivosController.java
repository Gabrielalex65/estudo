package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class ArquivosController implements IArquivosController {

	public ArquivosController() {
		
	}
	public static int cont;
	public void verificaDirTemp() throws IOException {
		String path = "C:\\teste2";
		File dir = new File(path);
		if(dir.exists() && dir.isDirectory()) {
			System.out.print("Diretorio existe");
		} else {
			File arq = new File(path,"cadastro"+".csv");
			dir.mkdir();
			String conteudo = "Codigo; nome; email";
			FileWriter fileWriter = new FileWriter(arq,false);
			PrintWriter print = new PrintWriter(fileWriter);
			print.println(conteudo);
			print.flush();
			print.close();
			fileWriter.close();
		}
}
	
	@Override
	public boolean verificaRegistro(String arquivo, int codigo) throws IOException {
		File arq = new File("C:\\teste2",arquivo);
		boolean existe = false;
		if(arq.exists() && arq.isFile()) {
			FileInputStream fluxo = new FileInputStream(arq);
			InputStreamReader leitor = new InputStreamReader(fluxo,"UTF-8");
			BufferedReader buffer = new BufferedReader(leitor);
			String aux;
			aux = Integer.toString(codigo);
			String linha = buffer.readLine();
			 linha = buffer.readLine();
			while(linha != null) {
				char[] chars = linha.toCharArray();
			      StringBuilder sb = new StringBuilder();
			      for(char c : chars){
			    	  if(c == ';') {
			    		    linha = buffer.readLine();
			    	  }
			         if(Character.isDigit(c)){
			            sb.append(c);
						if(aux.contentEquals(sb)) {
							existe = true;
						}
			         } 
			      }
			}
			buffer.close();
			leitor.close();
			fluxo.close();
			return existe;
		} else {
			throw new IOException("Arquivo Invalido");
		}
	}


	@Override
	public void imprimeCadastro(String arquivo, int codigo) throws IOException {
		if(verificaRegistro(arquivo,codigo)) {
		File arq = new File("C:\\teste2",arquivo);
			FileInputStream fluxo = new FileInputStream(arq);
			InputStreamReader leitor = new InputStreamReader(fluxo,"UTF-8");
			BufferedReader buffer = new BufferedReader(leitor);
			String linha = buffer.readLine();
			String aux;
			aux = Integer.toString(codigo);
			 linha = buffer.readLine();
			while(linha != null) {
				char[] chars = linha.toCharArray();
			      StringBuilder sb = new StringBuilder();
			      for(char c : chars){
			    	  if(c == ';') {
			    		    linha = buffer.readLine();
			    	  }
			         if(Character.isDigit(c)){
			            sb.append(c);
						if(aux.contentEquals(sb)) {
							System.out.println(linha);
						}
			         } 
			      }
			}
			buffer.close();
			leitor.close();
			fluxo.close();
		
		} else {
			throw new IOException("Sem cadastro");
		}
	}
	
	@Override
	public void insereCadastro(String arquivo, int codigo, String nome, String email) throws IOException {
		if(verificaRegistro(arquivo,codigo)) {
			System.out.print("J� EXSITE");
		}	else {
			File arq = new File("C:\\teste2",arquivo);
			FileInputStream fluxo = new FileInputStream(arq);
			InputStreamReader leitor = new InputStreamReader(fluxo,"UTF-8");
			BufferedReader buffer = new BufferedReader(leitor);
			String linha = buffer.readLine();
			FileWriter fileWriter = new FileWriter(arq,true);
			PrintWriter print = new PrintWriter(fileWriter);
			while(linha != null) {
				linha = buffer.readLine();
			}
			linha = codigo+";"+nome+";"+email;
			print.println(linha);
			print.flush();
			print.close();
			fileWriter.close();
			buffer.close();
			leitor.close();
			fluxo.close();
		}
	}
}
