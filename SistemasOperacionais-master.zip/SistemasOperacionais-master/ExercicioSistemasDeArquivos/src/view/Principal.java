package view;

import java.io.IOException;

import javax.swing.JOptionPane;

import controller.ArquivosController;
import controller.IArquivosController;

public class Principal {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		IArquivosController arqCont = new ArquivosController();
		int opc = 0,codigo = 0;
		String arquivo = "cadastro.csv",nome,email;
		while(opc != 99) {
			opc = Integer.parseInt(JOptionPane.showInputDialog("1-cria/verifica se diretorio e arquivo existe\n 2-impressao de cadastro \n 3-inserir novo cadastro"));
			switch(opc) {
			case 1:
				arqCont.verificaDirTemp();
				break;
			case 2:
				codigo = Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo do cadastrado"));
				arqCont.imprimeCadastro(arquivo, codigo);
				break;
			case 3:
				codigo = Integer.parseInt(JOptionPane.showInputDialog("Digite o codigo para cadastro"));
				nome = JOptionPane.showInputDialog("Digite o nome para cadastro");
				email = JOptionPane.showInputDialog("Digite o email para cadastro");
				arqCont.insereCadastro(arquivo, codigo, nome, email);
				break;
			}
		}
	}

}
