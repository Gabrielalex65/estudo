package View;

import Controller.IArquivosController;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

import Controller.ArquivosController;

public class Principal {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int op = 98;
		IArquivosController arqCont = new ArquivosController();
		String dirWin = "C:\\Users\\gabri\\Desktop\\SO";
		
		String nome = "relatorio.txt";
		
		try {
			while(op != 99) {
				op = Integer.parseInt(JOptionPane.showInputDialog("1-Criar Arquivo excel \n2-Ver arquivos da pasta\n"
						+ "3-Criar arquivo ou alterar txt txt\n4- Abrir arquivo txt \n5- ler Arquivo txt\n6-Abrir Arquivo excel\n 99-Fechar programa"));
			switch(op) {
			case 1:
				String conteudo = arqCont.readFile(dirWin, nome);
				String nomes = "relatorio";
				File arq = new File(dirWin,nomes+".csv");
				FileWriter fileWriter = new FileWriter(arq,false);
				PrintWriter print = new PrintWriter(fileWriter);
				print.write(conteudo);
				print.flush();
				print.close();
				fileWriter.close();
				break;
			case 2:
				arqCont.readDir(dirWin);
				break;
			case 3:
				String nomee = "relatorio";
				arqCont.createFile(dirWin, nomee);
				break;
			case 4:
				String nomeOpen = "relatorio.txt";
				arqCont.openFile(dirWin, nomeOpen);
				break;
			case 5:
				System.out.print(arqCont.readFile(dirWin, nome));
				break;
			case 6:
				String nomeOpens = "relatorio.csv";
				arqCont.openFile(dirWin, nomeOpens);
				break;
				}
			}
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
}
