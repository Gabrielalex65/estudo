package Exercicio1;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class ThreadAviao extends Thread{
	private Semaphore PistaNorte;
	private Semaphore PistaSul;
	private int pista = 0;
	private int Aviao;
	public ThreadAviao(int Aviao,Semaphore PistaNorte,Semaphore PistaSul) {
		this.Aviao = Aviao;
		this.PistaNorte = PistaNorte;
		this.PistaSul = PistaSul;
	}
	public void run() {
		Random gerador = new Random();
		pista = gerador.nextInt(2);
		if(pista == 0) {
			try {
			PistaNorte.acquire();
			} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			} finally {
				System.out.println(Aviao+" Est� na pista Pista Norte");
				manobrar();
				taxiar();
				decolar();
				afastamento();
				System.out.println(Aviao+" se afastou");
				PistaNorte.release();
				
			}
		} else if(pista == 1) {
			try {
				PistaSul.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				System.out.println(Aviao+" Est� na pista Pista Sul");
				manobrar();
				taxiar();
				decolar();
				afastamento();
				System.out.println(Aviao+"se afastou");
				PistaSul.release();
			}
		}
	}
	public void manobrar() {
		int tempo = (int)(Math.random()*4001)+3000;
		try {
			sleep(tempo);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void taxiar() {
		int tempo = (int)(Math.random()*5001)+5000;
		try {
			sleep(tempo);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void decolar() {
		int tempo = (int)(Math.random()*3001)+1000;
		try {
			sleep(tempo);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void afastamento() {
		int tempo = (int)(Math.random()*5001)+3000;
		try {
			sleep(tempo);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
