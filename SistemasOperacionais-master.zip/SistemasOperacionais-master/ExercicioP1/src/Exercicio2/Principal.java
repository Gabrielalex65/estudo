package Exercicio2;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int Jogador = 0; Jogador < 10; Jogador++) {
		Thread tjokenpo = new ThreadJokenpo(Jogador);
		tjokenpo.start();
		}
	}

}
