package Exercicio2;

public class ThreadJokenpo extends Thread{
	static int QuantJog;
	int Jogador;
	static int[] timeA = new int[5];
	static int[] timeB = new int[5];
	public ThreadJokenpo(int Jogador) {
		this.Jogador = Jogador;
	}
	public void run() {
		if(QuantJog < 5) {
			timeA[QuantJog] = Jogador;
			System.out.print(timeA[QuantJog]);
		} else {
			timeB[QuantJog] = Jogador;
			System.out.print(timeB[QuantJog]);
		}
		QuantJog++;
	}
}
