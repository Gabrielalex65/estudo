import Exercicio
Exercicio.exercicio46()