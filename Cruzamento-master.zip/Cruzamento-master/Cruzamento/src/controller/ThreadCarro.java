package controller;

import java.util.concurrent.Semaphore;

public class ThreadCarro extends Thread {
	private int idCarro;
	private Semaphore semaforo;
	private static int posicaoChegada;
	private static int posicaoSaida;
	public ThreadCarro(int idCarro, Semaphore semaforo) {
		this.idCarro = idCarro;
		this.semaforo = semaforo;
	}

public void run() {
	//Secao critica --------P(Acquire)-------------
	try {
		semaforo.acquire();
		carroAndando();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} finally {
	//-----------V (Release)-------------------
    carroSaindo();
	semaforo.release();
	}
}
private void carroAndando() {
	int distanciaTotal = (int)((Math.random() *401) + 1500);
	int distanciaPercorrida = 0;
	int deslocamento = 100;
	int tempo = 30;
	System.out.println("#"+idCarro+"Iniciou travessia");
	while(distanciaPercorrida < distanciaTotal){
		distanciaPercorrida += deslocamento;
		try {
			sleep(tempo);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("#"+idCarro+"andou"+distanciaPercorrida+"m.");
		
		}
	}
private void carroSaindo(){
	posicaoSaida++;
	System.out.println("#"+idCarro+"terminou a travessia");
	}
}
